var myMap = L.map("map", {
  center: [38, -97],
  zoom: 5,
  });

  // Define variables for our tile layers
L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.light",
  accessToken: API_KEY
}).addTo(myMap);

citymarkers = [];

// An array of cities and their locations
var cities = [
  {
    name: "Austin",
    location: [30.2, -97.7]
  },
  {
    name: "Seattle",
    location: [47.6, -122.3]
  },
  {
    name: "Miami",
    location: [25.7, -80.2]
  }
];

function remover() {
  for (i = 0; i< cities.length; i++) {
    myMap.removeLayer(citymarkers[i])
  }
}

function adder(value) {
  for (i = 0; i< cities.length; i++) {
    citymarkers.push(L.marker(cities[i].location))
  };
  for (i = 0; i< cities.length; i++) {
    citymarkers[i].bindPopup(`<h1>Name: ${cities[i].name} ${value}  </h1>`)
    .addTo(myMap)
  };
}
var coord = L.latLng(25.7, -80.3);

//L.circle(coord, {color:"red",radius:200}).addTo(myMap)

console.log(cities[0].location)
var cityMarkers = [];

adder(1);

slider = L.control.slider(function(value) {
  console.log(value);
  remover()
  adder(value)
},
{
min: 1,
max: 10,
value: 1,
collapsed: false,
showValue: false,
step:1,
size: '1000px',
orientation:'horizontal',
position: 'bottomleft',
id: 'slider',
increment: 'true'
}).addTo(myMap);







// // Pass our map layers into our layer control
// // Add the layer control to the map




