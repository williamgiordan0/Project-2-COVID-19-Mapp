// An array of cities and their locations
var cities = [
  {
    name: "Paris",
    location: [48.8566, 2.3522]
  },
  {
    name: "Lyon",
    location: [45.7640, 4.8357]
  },
  {
    name: "Cannes",
    location: [43.5528, 7.0174]
  },
  {
    name: "Nantes",
    location: [47.2184, -1.5536]
  }
];


// An array which will be used to store created cityMarkers
var cityMarkers = [];

for (var i = 0; i < cities.length; i++) {
  // loop through the cities array, create a new marker, push it to the cityMarkers array
  cityMarkers.push(
    L.marker(cities[i].location).bindPopup("<h1>" + cities[i].name + "</h1>")
  );
}
// Add all the cityMarkers to a new layer group.
// Now we can handle them as one group instead of referencing each individually
var cityLayer = L.layerGroup(cityMarkers);


// Define variables for our tile layers
var light = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.light",
  accessToken: API_KEY
});

var dark = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.dark",
  accessToken: API_KEY
});

// Only one base layer can be shown at a time
var baseMaps = {
  Light: light,
  Dark: dark
};

// Overlays that may be toggled on or off
var overlayMap = {
  Cities: cityLayer,
};



// Create map object and set default layers
var myMap = L.map("map", {
  center: [46.2276, 2.2137],
  zoom: 6,
  layers: [light, cityLayer]
});

var i = 0;
var j = 0;
slider = L.control.slider(function(value) {
  console.log(value);
  if (value > 3) {
    L.marker([48, 5 + i/5]).addTo(myMap)
        .bindPopup(`Allouette ${i}`);
        i = i+1;
  }
  else {
    L.marker([43, 0 + j/5]).addTo(myMap)
    .bindPopup(`La Baguette ${j})`);
    j = j+1;}
  }, 
  {
max: 6,
value: 5,
collapsed: false,
step:0.1,
size: '250px',
orientation:'vertical',
position: 'topright',
id: 'slider'
}).addTo(myMap);

// Pass our map layers into our layer control
// Add the layer control to the map
L.control.layers(baseMaps, overlayMap).addTo(myMap);

// if (sv > 2) {
// L.marker([48, 5]).addTo(myMap)
//     .bindPopup('Allouette');

// L.marker([43, 0]).addTo(myMap)
// .bindPopup('La Baguette');
//}
    //.openPopup();

// {
//   name: "Allouette",
//   location: [48.8566, 2.3522]
// },
// {
//   name: "La Baguette",
//   location: [45.7640, 4.8357]
// },

